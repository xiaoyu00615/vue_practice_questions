


const findValue = document.querySelector('.find')
const container = document.querySelector('.container')
// const del = document.querySelector('.del')

function findData(dataAll,value){
    return dataAll.find((item,index)=>{
        if (item.款号=== value) return index + 1
    })
}

function delDemo(demo){
    demo.replaceChildren()
}

// del.addEventListener('click',function (){
//     delDemo(container)
// })


findValue.addEventListener('click',function (){
    let intValue = document.querySelector('.int-value').value
    intValue = intValue.toUpperCase()
    console.log(data,intValue)

    let value = findData(data,intValue)
    console.log(value)
    if (value === undefined) {
        alert("没有查询到！！！")
        return
    }
    repeatValue()

    animateData(value)
})

function animateData(obj){
    const getNode = document.querySelector('.container').children.length
    if (getNode) delDemo(container)

    // 款号
    let id = obj.款号
    // 现折扣
    let rediscount = obj.现折扣
    // 标准价
    let standardPrice = obj.标准价
    // 系列
    let series = obj.系列


    console.log(id , rediscount , standardPrice ,series)



    let html = `
        <div class="animates">
            <p>款号：<span>${id}</span></p>
            <p>现折扣：<span>${rediscount}</span></p>
            <p>标准价：<span>${standardPrice}</span></p>
            <p>系列：<span>${series}</span></p>
        </div>
    `

    container.insertAdjacentHTML('beforeend',html)
}


function repeatValue(){
    document.querySelector('.int-value').value = ''
}