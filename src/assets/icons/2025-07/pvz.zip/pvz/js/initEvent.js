function initEvent() {
    $('.card-item').click(function () {
        // 这种方式会被覆盖
        // $(this).addClass('active').siblings().removeClass('active')

        // 删除 卡片项的选中状态
        $('.card-item .active').remove()

        // 创建一个盒子覆盖住卡牌项代表选中状态
        let newActive = $('<div class="active"></div>')
        $(this).append(newActive)

        // 重复点击取消选择
        if (data.now_plant === $(this).data('plant')){
            data.now_plant = null
            $('.card-item .active').remove()
            return
        }
        data.now_plant = $(this).data('plant')
    })
}

// 修改阳光
function upDataSun(num){
    data.sun_num += num
    if (data.sun_num >= GameRegion.SUNNUMBERMAX){
        data.sun_num = GameRegion.SUNNUMBERMAX
    }
    $('.top-bar .sun span').text(data.sun_num)
}
