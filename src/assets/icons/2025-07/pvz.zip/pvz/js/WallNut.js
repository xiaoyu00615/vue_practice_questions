class WallNut{
    constructor(type,x,y) {
        this.plantLifeMax = 2000
        this.life = 2000

        this.x = x
        this.y = y

        this.imgName = WallNutImages

        this.height = 80
        this.width = 80
        this.type = type
        this.index = 0
        this.index_all = 0
        this.index_step = 0.3

        this.init()
    }

    init(){
        upDataSun(-50)
        let{ x,y } = countPlantPos(this.x,this.y,this.width,this.height)
        this.x = x
        this.y = y
    }

    drawPlantFun() {
        if (this.type === 'wallnut' || this.type === 'wallnut_cracked1' || this.type === 'wallnut_cracked2') {
            // 晃动速率
            this.index_all += this.index_step

            // 判断是否到达临界值
            this.index = Math.floor(this.index_all)

            // 周期重复
            if (this.index >= Object.keys(this.imgName).length) {
                this.index = 0
                this.index_all = 0
            }
            // 绘制坚果墙图片
            try{
                ctx.drawImage(this.imgName[`${this.type}_${this.index}`], this.x, this.y, this.width, this.height)
            }catch (e){
                this.index = 0
                this.index_all = 0
            }


            drawBlood(this.x,this.y - 20,this.width,'rgb(170, 219, 114)','rgb(0, 107, 32)',this.life,this.plantLifeMax)
        }
    }

    delPlant(){

    }

    countHurt(hurtNum){
        this.life -= hurtNum
        // 死亡状态
        if(this.life <= 0){
            Plants.splice(Plants.indexOf(this),1)
        }else{
            // 未死状态
        }

        if(this.life <= this.plantLifeMax - Math.floor(this.plantLifeMax * 30 / 100) ){
            this.imgName = WallNutCracked1Images
            this.type = 'wallnut_cracked1'
            console.log("受伤状态一")
        }

        if (this.life <= this.plantLifeMax - Math.floor(this.plantLifeMax * 70 / 100)){
            this.imgName = WallNutCracked2Images
            this.type = 'wallnut_cracked2'
            console.log("受伤状态二")
        }
    }
}