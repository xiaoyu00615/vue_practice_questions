// 游戏基础数据
const GameRegion = {
    // 草坪列数量
    COLS : 11,
    // 草坪行数量
    ROWS : 5,
    // 草坪大小
    SIZE: 120,
    // 子弹发射间隔
    BULLETTIMER: 3,
    // 画布宽度
    CANVASWIDTH : 1200,
    // 画布高度
    CANVASHEIGHT: 600,
    // 阳光生成间隔
    SKYSUNTIMER: 6,
    // 阳光保留时间
    SKYSUNSAVETIMER:8,
    // 最大阳光储存量
    SUNNUMBERMAX:9999,
    // 植物大小
    PLANTSIZE:80,
    // 僵尸生成间隔
    ZOMBIETIMER:5,
    // 血条宽度
    BLOODBARWIDTH: 60,
    // 血条高度
    BLOODBARHEIGHT: 10
}

// 基础影子图片 - 子弹 - 阳光图片
const images = {
    sun :'./images/Plants/SunFlower/SunFlower_0.png',
    peashooter:'./images/Plants/Peashooter/Peashooter_0.png',
    potatomine:'./images/Plants/PotatoMine/PotatoMine/PotatoMine_0.png',
    wallnut:'./images/Plants/WallNut/WallNut/WallNut_0.png',

    peashooterBullet:'images/Bullets/PeaNormal/PeaNormal_0.png',
    PeaNormalExplode:'images/Bullets/PeaNormalExplode/PeaNormalExplode_0.png',

    skySun:'images/Plants/Sun/Sun_0.png',
    shovel:'images/Screen/shovel.png'
}



