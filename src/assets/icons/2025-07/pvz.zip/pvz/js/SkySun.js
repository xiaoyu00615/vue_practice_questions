// 阳光实例 天空阳光 - 生成阳光
class SkySun{
    // x轴 , y轴 ， 是否来自天空 ， y轴下落停止位置
    constructor(x,y,hasFormSky = true,yStop = 400) {
        this.hasFormSky = hasFormSky
        // 图片名称
        this.sunName = 'skySun'
        // 大小
        this.size = 78
        // 下落步长
        this.downStep = 3
        this.y = y
        this.x = x
        this.yStop = yStop
        // 下落时间 -> 定时器名称 (删除定时器)
        this.downTimer = null

        // 初始化调用
        this.init()
    }

    // 初始化
    init(){
        // 判断这个太阳是否来自天空
        if(this.hasFormSky) {
            // 随机 x轴下下落
            this.getPosX()
            // 随机 y轴停止位置
            this.getPosYStop()
        }
        // 到时间后进行删除操作
        this.hasTimer()
    }

    // 阳光 X轴偏移
    getPosX(){


        let x = createRandom(GameRegion.CANVASWIDTH)
        // x轴 边界情况
        if (x >= GameRegion.CANVASWIDTH - this.size  || x <= -this.size){
            this.getPosX()
            return
        }
        this.x = x
    }

    // 获取 Y轴停止位置
    getPosYStop(){
        let y = createRandom(GameRegion.CANVASWIDTH)
        // y轴 边界情况
        if (y >= GameRegion.CANVASHEIGHT - this.size || y <= this.size + 20){
            this.getPosYStop()
            return
        }
        this.yStop = y
    }

    // 绘制阳光
    drawSun(){

        // 到达指定位置停止下落
        if (!(this.y >= this.yStop)) {
            this.y += this.downStep
        }

        // 绘制
        ctx.drawImage(images[this.sunName],this.x,this.y,this.size,this.size)



    }

    // 删除阳光
    delSun(){
        // 找到对应的内存地址
        let index = SkySuns.indexOf(this)
        // 删除这个内存地址索引的数组项
        SkySuns.splice(index,1)
        // 清除定时器 -> 不然以后的阳光计时会造成混乱
        clearTimeout(this.downTimer)
    }

    // 计时消失
    hasTimer(){
        // 开始计时
        this.downTimer = setTimeout(()=>{
            // 时间到后清除
            this.delSun()
        },GameRegion.SKYSUNSAVETIMER * 1000)
    }

    // 拾取阳光
    // 挂载到了 单击canvas 的事件里 传递鼠标点击的 实际位置
    clickSkySun(mouse_pos){
        // 判断是否碰撞
        if(
            // 判断 x轴是否接触
            // 鼠标点击后的 x轴 <= 这个阳光的 (x轴 位置 + 阳光大小的宽) 最右边
            mouse_pos.x <= this.x + this.size &&
            // 鼠标点击后的 x轴 >= 这个阳光的最左边
            mouse_pos.x >= this.x &&

            // 判断 y轴是否接触
            // 鼠标点击后的 y轴 <= 这个阳光的 (y轴 位置 + 阳光大小的高) 最下面
            mouse_pos.y <= this.y + this.size &&
            // 鼠标点击后的 y轴 >= 这个阳光的最上面
            mouse_pos.y >= this.y
        ){
            // 确定碰撞了之后 修改阳光
            // 天空添加 100阳光
            if (this.hasFormSky){
                upDataSun(100)
            }else{
                // 创建的给50阳光
                upDataSun(50)
            }
            // 删除当前实例
            this.delSun()

        }
    }



}