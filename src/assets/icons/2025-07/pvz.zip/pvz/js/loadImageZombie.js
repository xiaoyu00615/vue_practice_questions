const ZombieImages = {
    zombie_0 : './images/Zombies/NormalZombie/Zombie/Zombie_0.png',
    zombie_1 : './images/Zombies/NormalZombie/Zombie/Zombie_1.png',
    zombie_2 : './images/Zombies/NormalZombie/Zombie/Zombie_2.png',
    zombie_3 : './images/Zombies/NormalZombie/Zombie/Zombie_3.png',
    zombie_4 : './images/Zombies/NormalZombie/Zombie/Zombie_4.png',
    zombie_5 : './images/Zombies/NormalZombie/Zombie/Zombie_5.png',
    zombie_6 : './images/Zombies/NormalZombie/Zombie/Zombie_6.png',
    zombie_7 : './images/Zombies/NormalZombie/Zombie/Zombie_7.png',
    zombie_8 : './images/Zombies/NormalZombie/Zombie/Zombie_8.png',
    zombie_9 : './images/Zombies/NormalZombie/Zombie/Zombie_9.png',
    zombie_10 : './images/Zombies/NormalZombie/Zombie/Zombie_10.png',
    zombie_11 : './images/Zombies/NormalZombie/Zombie/Zombie_11.png',
    zombie_12 : './images/Zombies/NormalZombie/Zombie/Zombie_12.png',
    zombie_13 : './images/Zombies/NormalZombie/Zombie/Zombie_13.png',
    zombie_14 : './images/Zombies/NormalZombie/Zombie/Zombie_14.png',
    zombie_15 : './images/Zombies/NormalZombie/Zombie/Zombie_15.png',
    zombie_16 : './images/Zombies/NormalZombie/Zombie/Zombie_16.png',
    zombie_17 : './images/Zombies/NormalZombie/Zombie/Zombie_17.png',
    zombie_18 : './images/Zombies/NormalZombie/Zombie/Zombie_18.png',
    zombie_19 : './images/Zombies/NormalZombie/Zombie/Zombie_19.png',
    zombie_20 : './images/Zombies/NormalZombie/Zombie/Zombie_20.png',
    zombie_21 : './images/Zombies/NormalZombie/Zombie/Zombie_21.png'
}

// 僵尸啃咬帧动画
const ZombieAttackImages = {
    zombieAttack_0: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_0.png',
    zombieAttack_1: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_1.png',
    zombieAttack_2: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_2.png',
    zombieAttack_3: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_3.png',
    zombieAttack_4: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_4.png',
    zombieAttack_5: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_5.png',
    zombieAttack_6: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_6.png',
    zombieAttack_7: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_7.png',
    zombieAttack_8: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_8.png',
    zombieAttack_9: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_9.png',
    zombieAttack_10: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_10.png',
    zombieAttack_11: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_11.png',
    zombieAttack_12: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_12.png',
    zombieAttack_13: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_13.png',
    zombieAttack_14: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_14.png',
    zombieAttack_15: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_15.png',
    zombieAttack_16: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_16.png',
    zombieAttack_17: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_17.png',
    zombieAttack_18: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_18.png',
    zombieAttack_19: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_19.png',
    zombieAttack_20: './images/Zombies/NormalZombie/ZombieAttack/ZombieAttack_20.png'
}


function loadAllImagesZombie(){
    loadImage(ZombieImages)
    loadImage(ZombieAttackImages)
}