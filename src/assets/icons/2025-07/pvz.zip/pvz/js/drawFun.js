// 绘制植物
function drawPlant(plants){
    plants.forEach((plant)=>{
        plant.drawPlantFun()
    })
}

// 绘制植物列表  --- pass
// function drawPlant(plants){
//     if (plants.length <= 0) return
//     plants.forEach((plant)=>{
//         let { col,row,type } = plant
//
//         const x = col * GameRegion.SIZE
//         const y = row * GameRegion.SIZE
//
//         // 绘制
//         ctx.drawImage(images[type],x,y,GameRegion.SIZE,GameRegion.SIZE)
//     })
// }

// 绘制子弹
function drawBullets (Bullets){
    if (Bullets.length <= 0) return
    Bullets.forEach((bullet)=>{
        bullet.drawBullets()
    })
}

// 添加天空阳光
function addSkySun(){
    setInterval(()=>{
        SkySuns.push(new SkySun(0,0))
    },GameRegion.SKYSUNTIMER * 1000)

}

// 绘制天空阳光
function drawSkySun(SkySuns){
    if (SkySuns.length <= 0) return
    SkySuns.forEach((skySun)=>{
        skySun.drawSun()
    })
}


// 添加推入待渲染列表
function addZombie(){
    let x = 1000
    setInterval(function(){
        let randomY = getRowZombie()
        Zombies.push(new Zombie("zombie",x,randomY.randomNum))

        // 保存记录哪当前行出现的僵尸

        zombieRow[randomY.index[0]] = true




    },GameRegion.ZOMBIETIMER * 1000)


}

// 绘制僵尸
function drawZombie(zombies){
    zombies.forEach((zombie)=>{
        zombie.drawZombie()
    })
}
