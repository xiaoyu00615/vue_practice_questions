class Zombie {
    constructor(type,x,y) {
        this.plantLifeMax = 200
        this.life = 200
        this.index_all = 0
        this.index_step = 0.3
        this.x_step = 0.3
        this.index = 0

        this.hurtNum = 2

        this.type = type
        this.x = x
        this.y = y

        this.has_gnaw = false

        this.height = 120
        this.width = 136
    }

    drawZombie(){
        if (this.type === 'zombie'){
            // 晃动速率
            this.index_all += this.index_step
            // 判断是否到达临界值
            this.index = Math.floor(this.index_all)

            // 周期重复
            if (this.index >= Object.keys(this.has_gnaw ? ZombieAttackImages : ZombieImages).length){
                this.index = 0
                this.index_all = 0
            }

            let isCollision = false
            Plants.forEach((plant)=>{

                if (zombieCollisionPlant(this,plant)){
                    // console.log("啃到植物 -> 上岸")
                    plant.countHurt(this.hurtNum)

                    isCollision = true
                }
            })

            this.has_gnaw = isCollision

            if (!this.has_gnaw){
                this.x -= this.x_step
            }
            if(this.x <= -20){
                Zombies.splice(Zombies.indexOf(this),1)
            }

            // 绘制普通僵尸
            try {
                ctx.drawImage(this.has_gnaw ? ZombieAttackImages[`${this.has_gnaw ? 'zombieAttack' : this.type}_${this.index}`] : ZombieImages[`${this.has_gnaw ? 'zombieAttack' : this.type}_${this.index}`],this.x,this.y,this.width,this.height)
            }catch (e){
                this.index = 0
                this.index_all = 0

            }

            drawBlood(this.x,this.y,this.width,'rgb(219, 97, 81)','red',this.life,this.plantLifeMax)
        }
    }


    countHurt(hurtNum){
        this.life -= hurtNum
        // 死亡状态
        if(this.life <= 0){
            console.log("我还会再回来的")
            Zombies.splice(Zombies.indexOf(this),1)
        }else{
            // 未死状态
        }
    }



}