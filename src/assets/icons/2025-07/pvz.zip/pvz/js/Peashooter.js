// 豌豆射手实例
class Peashooter{
    constructor(type,x,y,pos) {
        // 生命值
        this.plantLifeMax = 200
        this.life = 200
        // 花费阳光
        this.cost = 100
        this.x = x
        this.y = y
        this.pos = pos
        this.width = 80
        this.height = 80
        this.type = type
        // 图片索引
        this.index = 0
        // index自增速率
        this.index_all = 0
        // 速率
        this.index_step = 0.3
        // 创建阳光的间隔
        // this.createSunTimer = 4

        this.init()
    }

    init(){
        // 修改阳光
        upDataSun(-this.cost)

        // 绘制子弹
        // this.drawPeashooterBullet()

        // this.x = this.x + ((GameRegion.SIZE - this.width )/ 2)
        // this.y = this.y + (GameRegion.SIZE - this.height)

        // 计算位置
        let{ x,y } = countPlantPos(this.x,this.y,this.width,this.height)
        this.x = x
        this.y = y

        setInterval(()=>{
            this.drawPeashooterBullet()
        },GameRegion.BULLETTIMER * 1000)

    }




    drawPlantFun(){
        if (this.type === 'peashooter'){
            // 晃动速率
            this.index_all += this.index_step

            // 判断是否到达临界值
            this.index = Math.floor(this.index_all)

            // 周期重复
            if (this.index >= Object.keys(peashooterImages).length){
                this.index = 0
                this.index_all = 0
            }


            // 绘制豌豆射手
            ctx.drawImage(peashooterImages[`${this.type}_${this.index}`],this.x,this.y,this.width,this.height)
        }
        drawBlood(this.x,this.y - 20,this.width,'rgb(170, 219, 114)','rgb(0, 107, 32)',this.life,this.plantLifeMax)
    }

    drawPeashooterBullet(){
        if(!(zombieRow[this.pos.row])){
            this.delPlant()
            return
        }
        this.timerPlant = setTimeout(()=>{
            Bullets.push(new Bullet("peashooterBullet",this.x,this.y,this.pos))
        },GameRegion.BULLETTIMER * 1000)
    }


    delPlant(){
        clearInterval(this.timerPlant)
    }

    countHurt(hurtNum){
        this.life -= hurtNum
        // 死亡状态
        if(this.life <= 0){

            Plants.splice(Plants.indexOf(this),1)
            this.delPlant()
        }else{
            // 未死状态
        }
    }
}
