
// 向日葵帧动画图片
const SunFlowerImages = {
    sun_0 :'./images/Plants/SunFlower/SunFlower_0.png',
    sun_1 :'./images/Plants/SunFlower/SunFlower_1.png',
    sun_2 :'./images/Plants/SunFlower/SunFlower_2.png',
    sun_3 :'./images/Plants/SunFlower/SunFlower_3.png',
    sun_4 :'./images/Plants/SunFlower/SunFlower_4.png',
    sun_5 :'./images/Plants/SunFlower/SunFlower_5.png',
    sun_6 :'./images/Plants/SunFlower/SunFlower_6.png',
    sun_7 :'./images/Plants/SunFlower/SunFlower_7.png',
    sun_8 :'./images/Plants/SunFlower/SunFlower_8.png',
    sun_9 :'./images/Plants/SunFlower/SunFlower_9.png',
    sun_10 :'./images/Plants/SunFlower/SunFlower_10.png',
    sun_11 :'./images/Plants/SunFlower/SunFlower_11.png',
    sun_12 :'./images/Plants/SunFlower/SunFlower_12.png',
    sun_13 :'./images/Plants/SunFlower/SunFlower_13.png',
    sun_14 :'./images/Plants/SunFlower/SunFlower_14.png',
    sun_15 :'./images/Plants/SunFlower/SunFlower_15.png',
    sun_16 :'./images/Plants/SunFlower/SunFlower_16.png',
    sun_17 :'./images/Plants/SunFlower/SunFlower_17.png',
}

// 豌豆射手帧动画图片
const peashooterImages = {
    peashooter_0:'./images/Plants/Peashooter/Peashooter_0.png',
    peashooter_1:'./images/Plants/Peashooter/Peashooter_1.png',
    peashooter_2:'./images/Plants/Peashooter/Peashooter_2.png',
    peashooter_3:'./images/Plants/Peashooter/Peashooter_3.png',
    peashooter_4:'./images/Plants/Peashooter/Peashooter_4.png',
    peashooter_5:'./images/Plants/Peashooter/Peashooter_5.png',
    peashooter_6:'./images/Plants/Peashooter/Peashooter_6.png',
    peashooter_7:'./images/Plants/Peashooter/Peashooter_7.png',
    peashooter_8:'./images/Plants/Peashooter/Peashooter_8.png',
    peashooter_9:'./images/Plants/Peashooter/Peashooter_9.png',
    peashooter_10:'./images/Plants/Peashooter/Peashooter_10.png',
    peashooter_11:'./images/Plants/Peashooter/Peashooter_11.png',
    peashooter_12:'./images/Plants/Peashooter/Peashooter_12.png',
}


// 坚果墙帧动画图片
const WallNutImages = {
    wallnut_0 : './images/Plants/WallNut/WallNut/WallNut_0.png',
    wallnut_1 : './images/Plants/WallNut/WallNut/WallNut_1.png',
    wallnut_2 : './images/Plants/WallNut/WallNut/WallNut_2.png',
    wallnut_3 : './images/Plants/WallNut/WallNut/WallNut_3.png',
    wallnut_4 : './images/Plants/WallNut/WallNut/WallNut_4.png',
    wallnut_5 : './images/Plants/WallNut/WallNut/WallNut_5.png',
    wallnut_6 : './images/Plants/WallNut/WallNut/WallNut_6.png',
    wallnut_7 : './images/Plants/WallNut/WallNut/WallNut_7.png',
    wallnut_8 : './images/Plants/WallNut/WallNut/WallNut_8.png',
    wallnut_9 : './images/Plants/WallNut/WallNut/WallNut_9.png',
    wallnut_10 : './images/Plants/WallNut/WallNut/WallNut_10.png',
    wallnut_11 : './images/Plants/WallNut/WallNut/WallNut_11.png',
    wallnut_12 : './images/Plants/WallNut/WallNut/WallNut_12.png',
    wallnut_13 : './images/Plants/WallNut/WallNut/WallNut_13.png',
    wallnut_14 : './images/Plants/WallNut/WallNut/WallNut_14.png',
    wallnut_15 : './images/Plants/WallNut/WallNut/WallNut_15.png'
}

// 坚果受伤一级
const WallNutCracked1Images = {
    wallnut_cracked1_0 : './images/Plants/WallNut/WallNut_cracked1/WallNut_cracked1_0.png',
    wallnut_cracked1_1 : './images/Plants/WallNut/WallNut_cracked1/WallNut_cracked1_1.png',
    wallnut_cracked1_2 : './images/Plants/WallNut/WallNut_cracked1/WallNut_cracked1_2.png',
    wallnut_cracked1_3 : './images/Plants/WallNut/WallNut_cracked1/WallNut_cracked1_3.png',
    wallnut_cracked1_4 : './images/Plants/WallNut/WallNut_cracked1/WallNut_cracked1_4.png',
    wallnut_cracked1_5 : './images/Plants/WallNut/WallNut_cracked1/WallNut_cracked1_5.png',
    wallnut_cracked1_6 : './images/Plants/WallNut/WallNut_cracked1/WallNut_cracked1_6.png',
    wallnut_cracked1_7 : './images/Plants/WallNut/WallNut_cracked1/WallNut_cracked1_7.png',
    wallnut_cracked1_8 : './images/Plants/WallNut/WallNut_cracked1/WallNut_cracked1_8.png',
    wallnut_cracked1_9 : './images/Plants/WallNut/WallNut_cracked1/WallNut_cracked1_9.png',
    wallnut_cracked1_10 : './images/Plants/WallNut/WallNut_cracked1/WallNut_cracked1_10.png'
}

// 坚果受伤二级
const WallNutCracked2Images = {
    wallnut_cracked2_0 : './images/Plants/WallNut/WallNut_cracked2/WallNut_cracked2_0.png',
    wallnut_cracked2_1 : './images/Plants/WallNut/WallNut_cracked2/WallNut_cracked2_1.png',
    wallnut_cracked2_2 : './images/Plants/WallNut/WallNut_cracked2/WallNut_cracked2_2.png',
    wallnut_cracked2_3 : './images/Plants/WallNut/WallNut_cracked2/WallNut_cracked2_3.png',
    wallnut_cracked2_4 : './images/Plants/WallNut/WallNut_cracked2/WallNut_cracked2_4.png',
    wallnut_cracked2_5 : './images/Plants/WallNut/WallNut_cracked2/WallNut_cracked2_5.png',
    wallnut_cracked2_6 : './images/Plants/WallNut/WallNut_cracked2/WallNut_cracked2_6.png',
    wallnut_cracked2_7 : './images/Plants/WallNut/WallNut_cracked2/WallNut_cracked2_7.png',
    wallnut_cracked2_8 : './images/Plants/WallNut/WallNut_cracked2/WallNut_cracked2_8.png',
    wallnut_cracked2_9 : './images/Plants/WallNut/WallNut_cracked2/WallNut_cracked2_9.png',
    wallnut_cracked2_10 : './images/Plants/WallNut/WallNut_cracked2/WallNut_cracked2_10.png',
    wallnut_cracked2_11 : './images/Plants/WallNut/WallNut_cracked2/WallNut_cracked2_11.png',
    wallnut_cracked2_12 : './images/Plants/WallNut/WallNut_cracked2/WallNut_cracked2_12.png',
    wallnut_cracked2_13 : './images/Plants/WallNut/WallNut_cracked2/WallNut_cracked2_13.png',
    wallnut_cracked2_14 : './images/Plants/WallNut/WallNut_cracked2/WallNut_cracked2_14.png',
}

// 加载全部图片
function loadAllImagesPlant(){
    // 基础图片
    loadImage(images)
    // 加载向日葵动态帧图片
    loadImage(SunFlowerImages)
    // 加载豌豆射手动态帧图片
    loadImage(peashooterImages)
    // 加载坚果动态帧图片
    loadImage(WallNutImages)
    // 加载坚果受伤一级动态帧图片
    loadImage(WallNutCracked1Images)
    // 加载坚果受伤二级动态帧图片
    loadImage(WallNutCracked2Images)
}


