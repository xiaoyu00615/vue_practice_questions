
// 子弹实例
class Bullet {
    // 子弹类型 ， x轴 ， y轴
    constructor(ballType,x,y,pos) {
        this.width = 53;
        this.height = 34

        this.pos = pos
        this.ex_width = 52
        this.ex_height = 46
        this.ballType = ballType
        // 移动步长
        this.step = 2
        this.x = x
        this.y = y

        this.hurt = 20
        // this.timer = 5
    }

    // 绘制子弹
    drawBullets(){
        // 当前位置
        this.x = this.x + this.step
        // 渲染
        ctx.drawImage(images[this.ballType],this.x + 50,this.y + 5,this.width,this.height)
        // 越界情况
        if (this.x >= 1200){

            // 通过筛选来获取对应的类
            const index = Bullets.indexOf(this)

            // 符合条件后删除1
            if (index !== -1){
                Bullets.splice(index,1)
            }

            zombieRow[this.pos.row] = false
        }

        Zombies.forEach((zombie)=>{
            if (bulletCollision(this,zombie)){
                ctx.drawImage(images["PeaNormalExplode"],this.x + this.width + 40,this.y,this.ex_width,this.ex_height)
                Bullets.splice(Bullets.indexOf(this),1)

                zombie.countHurt(this.hurt)

            }else{
                // console.log("还在飞")
            }
        })
    }
}