// 向日葵实例
class SunFlower {
    // 类型 ， x轴 , y轴
    constructor(type,x,y) {
        // 生命值
        this.plantLifeMax = 100
        this.life = 100
        // 花费阳光
        this.cost = 50
        this.x = x
        this.y = y
        this.height = 80
        this.width = 80
        this.type = type
        // 图片索引
        this.index = 0
        // index自增速率
        this.index_all = 0
        // 速率
        this.index_step = 0.3
        // 创建阳光的间隔
        this.createSunTimer = 6

        // 初始化调用
        this.init()
    }

    // 种植时消耗阳光
    init(){
        // 修改阳光数量
        upDataSun(-this.cost)

        // 并且开始计时创建阳光
        this.createSun()

        let {x , y} = countPlantPos(this.x,this.y,this.width,this.height)
        this.x = x
        this.y = y
    }


    // 绘制
    drawPlantFun(){
        if (this.type === 'sun'){
            // 晃动速率
            this.index_all += this.index_step

            // 判断是否到达临界值
            this.index = Math.floor(this.index_all)

            // 周期重复
            if (this.index >= Object.keys(SunFlowerImages).length){
                this.index = 0
                this.index_all = 0
            }
            // 绘制向日葵图片
            ctx.drawImage(SunFlowerImages[`${this.type}_${this.index}`],this.x,this.y,this.width,this.height)
        }
        drawBlood(this.x,this.y - 20,this.width,'rgb(170, 219, 114)','rgb(0, 107, 32)',this.life,this.plantLifeMax)
    }


    // 生成阳光
    createSun(){
        // 一段时间生成一个阳光
        this.timerPlant = setInterval(()=>{
            // 在一个区间生成下落的 x轴位置
            let x = createRandomBetween(this.x + 10 ,60)
            // y轴下落区间
            let yStop = createRandomBetween(this.y ,40)


            // 时间到了后 实例一个阳光 推入到待渲染列表中
            SkySuns.push(new SkySun(x,this.y,false,yStop))
        },this.createSunTimer * 1000)

    }


    delPlant(){
        clearInterval(this.timerPlant)
    }

    countHurt(hurtNum){
        this.life -= hurtNum
        // 死亡状态
        if(this.life <= 0){

            Plants.splice(Plants.indexOf(this),1)
            this.delPlant()
        }else{
            // 未死状态
        }
    }
}