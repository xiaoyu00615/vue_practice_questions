
// 绘制网格
function drawMap(COLS,ROWS,SIZE){
    ctx.save()
    ctx.strokeStyle = '#fff'
    ctx.lineWidth = 2

    // 行
    for(let row = 0; row < ROWS; row++){
        ctx.beginPath()
        ctx.moveTo(0,row * SIZE)
        ctx.lineTo(COLS * SIZE,row * SIZE)
        ctx.stroke()
    }

    // 列
    for(let col = 0; col < COLS; col++){
        ctx.beginPath()
        ctx.moveTo(col * SIZE , 0)
        ctx.lineTo(col * SIZE , ROWS * SIZE)
        ctx.stroke()
    }

    ctx.restore()
}


// 加载图片
function loadImage(images){
    for (const key in images ){
        const src = images[key]
        images[key] = new Image()
        images[key].src = src
    }
}

// 判断是否重合 实例属性内容
function findCell(item,arr){
    return arr.find((v)=>{
        return Math.floor(v.x / GameRegion.SIZE) === item.col &&
            Math.floor(v.y / GameRegion.SIZE) === item.row
    })
}

// 生成一个区间随机数
function createRandomBetween(min,max){
    return Math.floor(Math.random() * max+1 ) + min+1
}
// 最小 10 最大60
// console.log(createRandomBetween(10,50))


// 生成一个随机数 0 - max
function createRandom(max){
    return Math.floor(Math.random() * max + 1)
}

function getRowZombie(){
   let randomRowIndex = [Math.floor(Math.random() * 5)]
       return {
           randomNum :[0,120,240,360,480][randomRowIndex],
           index:randomRowIndex
       }
}




// 计算底边居中位置 x,y
function countPlantPos(x,y,width,height,size = GameRegion.SIZE){
    return {
        // 左右居中
        x : x + ((size - width ) / 2),
        // 底边
        y : y + (size - height)
    }
}

// 子弹碰撞僵尸
function bulletCollision(bullet,zombie){
    ctx.strokeRect (bullet.x,bullet.y,bullet.width,bullet.height)
    return bullet.x + bullet.width >= zombie.x &&
        bullet.x + bullet.width <= zombie.x + zombie.width &&
        bullet.y + (bullet.height / 2) >= zombie.y &&
        bullet.y + (bullet.height / 2) <= zombie.y + zombie.height
}

// 僵尸碰撞植物
function zombieCollisionPlant(zombie,plant){
    ctx.fillStyle = 'red'
    ctx.strokeRect (Math.floor(zombie.x),zombie.y,zombie.width,zombie.height)
    ctx.strokeRect (plant.x,plant.y,plant.width,plant.height)

    return zombie.x <= plant.x &&
        zombie.x >= plant.x - plant.width &&
        zombie.y + zombie.height >= plant.y &&
        zombie.y + zombie.height <= plant.y + plant.height
}

function drawBlood(x,y,width,bgColor,showColor,lift,lifeMax,BloodWidth = GameRegion.BLOODBARWIDTH,BloodHeight = GameRegion.BLOODBARHEIGHT){
    // 绘制血条
    ctx.fillStyle = bgColor
    ctx.fillRect(x + (width / 2 - BloodWidth / 2),y,BloodWidth,BloodHeight)

    // 绘制剩余血条
    ctx.fillStyle = showColor
    ctx.fillRect(x + (width / 2 - BloodWidth / 2),y,(lift /lifeMax) * BloodWidth,BloodHeight)
}


