// 全局使用的变量
// 绘制上下文工具
let ctx = null,
    // 画布
    canvas = null,
    // timer = null,
    // 请求帧
    rafId = null


// 初始游戏数据
let data = {
    // 阳光数量
    sun_num: 50,
    // 现在选中的植物
    now_plant: null,
    // 游戏时间
    timer: null,
}


// 记录鼠标位置
const mouse_pos = {
    // 经过位置
    hover_pos: null,
    // 点击位置
    click_pos: null
}

// 记录哪行出现僵尸
const zombieRow = new Array(5).fill(false)

// 待渲染植物列表
let Plants = []

// 待渲染子弹列表
let Bullets = []

// 待渲染天空阳光 - 生成阳光
let SkySuns = []

// 待渲染僵尸列表
let Zombies = []

// 开始游戏后的事件绑定
$(document).ready(()=>{

    // 加载全部植物图片
    loadAllImagesPlant()
    // 加载全部僵尸图片
    loadAllImagesZombie()


    // 初始化事件
    initEvent()

    // 获取画布
    canvas = $('canvas')
    // 绘制上下文工具
    ctx = canvas[0].getContext('2d')

    // 注册事件维护实时数据
    canvas.on('mousedown',mouseBus).on('mouseup',mouseBus).on('mousemove',mouseBus).on('mouseleave',mouseBus)

    // 开始游戏
    startGame()
})

const MOUSE_EVENT = {
    // 维护点击位置
    mousedown(pos,click_pos){

        // 必需在没有选择植物的时候收集阳光
        if (data.now_plant == null){
            // 场上如果没有阳光就不会触发点击效果
            SkySuns.forEach((skySun)=>{
                // 调用实例里面的 点击天空阳光函数 - 生成阳光
                skySun.clickSkySun(click_pos)
            })
        }

        // 点击时没有位置就直接返回
        if (data.now_plant === null) return

        // 判断如果是铲子
        if (data.now_plant === 'shovel'){
            if (findCell(pos,Plants)){
                let index = Plants.indexOf(findCell(pos,Plants))
                Plants[index].delPlant()
                Plants.splice(index,1)
            }else{

            }

        }


        // 查看是否重叠不可种植
        if (findCell(pos,Plants)){
            return;
        }

        // 维护点击位置
        mouse_pos.click_pos = {...pos}

        // 把点击的植物推入 --- pass
        // Plants.push({
        //     ...pos,
        //     type:data.now_plant
        // })

        // 计算实际画布位置
        const x = pos.col * GameRegion.SIZE
        const y = pos.row * GameRegion.SIZE

        // 依靠选择的植物卡片来确定实例哪个
        switch (data.now_plant){
            // 向日葵
            case 'sun':
                // if (data.sun_num < 50) return;
                Plants.push(new SunFlower(data.now_plant,x,y,pos))
                break

            case 'peashooter':
                // if (data.sun_num < 100) return;
                Plants.push(new Peashooter(data.now_plant,x,y,pos))
                break

            case 'wallnut':
                // if (data.sun_num < 50) return;
                Plants.push(new WallNut(data.now_plant,x,y,pos))
                break

        }


        // // 豌豆射手实例子弹 --- pass
        // if (data.now_plant === 'peashooter'){
        //     const x = pos.col * GameRegion.SIZE
        //     const y = pos.row * GameRegion.SIZE
        //     setInterval(function(){
        //         Bullets.push(new Bullet("peashooterBullet",x,y))
        //     },GameRegion.BULLETTIMER * 1000)
        // }




    },
    // 鼠标弹起将数据置空
    mouseup(){
        mouse_pos.hover_pos = null
        mouse_pos.click_pos = null
    },
    // 维护鼠标经过位置
    mousemove(pos){
        mouse_pos.hover_pos = {...pos}

        // 额外功能 -> 鼠标经过获取阳光 参数添加 click_pos
        // if (data.now_plant == null){
        //     // 场上如果没有阳光就不会触发点击效果
        //     SkySuns.forEach((skySun)=>{
        //         skySun.clickSkySun(click_pos)
        //     })
        // }
    },
    // 鼠标离开将数据置空
    mouseleave(){
        mouse_pos.hover_pos = null
        mouse_pos.click_pos = null
    }
}

function mouseBus(e){

    // 计算当前是在哪个格子里
    const pos = {
        col : Math.floor(e.offsetX / GameRegion.SIZE),
        row : Math.floor(e.offsetY / GameRegion.SIZE)
    }

    // 鼠标原始位置
    const click_pos = {
        x : e.offsetX,
        y : e.offsetY
    }

    // 可选链操作符
    MOUSE_EVENT[e.type]?.(pos,click_pos)
}

// 鼠标经过的影子
function mouseMove(){
    // 判断有没有必要数据 如果没有就返回
    if (data.now_plant === null || mouse_pos.hover_pos === null || images[data.now_plant] === undefined) return

    //  重叠不显示虚拟植物
    if (!(data.now_plant ===  'shovel')){
        if(findCell(mouse_pos.hover_pos,Plants)){
            return;
        }
    }


    // 计算坐标位置
    let x_pos = mouse_pos.hover_pos.col * GameRegion.SIZE
    let y_pos = mouse_pos.hover_pos.row * GameRegion.SIZE

    // 解构值
    let {x,y} = countPlantPos(x_pos,y_pos,GameRegion.PLANTSIZE,GameRegion.PLANTSIZE)

    // 绘制图片
    ctx.save()
    ctx.globalAlpha = '0.5'
    if (data.now_plant === 'shovel'){
        ctx.fillStyle = '#fff'
        ctx.fillRect(x_pos,y_pos,GameRegion.SIZE,GameRegion.SIZE)
    }
    ctx.drawImage(images[data.now_plant],x,y,GameRegion.PLANTSIZE,GameRegion.PLANTSIZE)
    ctx.restore()
}



function startGame(){
    // console.log("开始游戏")
    canvas = document.querySelector('canvas')
    ctx = canvas.getContext('2d')

    // 计时掉落天空阳光 -> public.js
    addSkySun()

    // 添加僵尸推入待渲染列表
    addZombie()

    // 调用主循环
    animate()
}




// 游戏主循环
function animate(){
    // 清除画布
    ctx.clearRect(0,0,1200,600)

    // console.log("循环递归")
    drawMap(GameRegion.COLS,GameRegion.ROWS,GameRegion.SIZE)



    // 渲染植物
    drawPlant(Plants)

    // 渲染虚拟植物
    mouseMove()

    // 渲染天空阳光
    drawSkySun(SkySuns)

    // 渲染子弹
    drawBullets(Bullets)

    // 绘制僵尸
    drawZombie(Zombies)
    // console.log(Zombies)

    // console.log(Bullets)

    // console.log(Plants)
    // 递归调用自己
    rafId = requestAnimationFrame(animate)
}




